#include "Engine.h"


int main()
{
	Engine engine(960, 540);
	engine.start();
}