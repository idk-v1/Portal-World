#pragma once
class TickScheduler
{
};

