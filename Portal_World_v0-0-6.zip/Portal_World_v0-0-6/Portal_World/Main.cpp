#include "Engine.h"


int main()
{
	Engine engine(16 * 60, 9 * 60);
	engine.start();
}