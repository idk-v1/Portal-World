#include "Engine.h"


int main()
{
	Engine engine(640, 480);
	engine.start();
}